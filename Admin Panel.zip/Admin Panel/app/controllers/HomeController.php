<?php

class HomeController extends BaseController {

	public function link1() {
		return View::make('error.404');
	}

	public function link2() {
		return View::make('error.404');
	}
	public function link3() {
		return View::make('error.404');
	}
	public function link4() {
		return View::make('error.404');
	}
	public function link5() {
		return View::make('error.404');
	}

}
