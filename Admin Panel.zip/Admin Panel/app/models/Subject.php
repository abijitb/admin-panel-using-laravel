<?php

class Subject extends Eloquent {

	protected $table = 'subjects';

}
