<?php

class LongQstn extends Eloquent {

	protected $table = 'long_questions';

}
