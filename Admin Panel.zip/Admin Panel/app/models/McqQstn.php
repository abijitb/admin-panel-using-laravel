<?php

class McqQstn extends Eloquent {

	protected $table = 'mcq_questions';

}
