<?php

class Year extends Eloquent {

	protected $table = 'years';

}
