<?php
	
	header('Location:public');